#ifndef VSF_OPTS_H
#define VSF_OPTS_H

struct vsf_session;

void handle_opts(struct vsf_session* p_sess);

#endif /* VSF_OPTS_H */

